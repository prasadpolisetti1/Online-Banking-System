<html>
<head>
<meta charset="utf-8">


<title>Sidebar Menu with sub-menu | CodingNepal</title>


<link rel="stylesheet" type="text/css" href="style.css">


</head>




<body>




<nav class="sidebar">

  <ul>




     <li><a href="userhome.php">Home</a></li>



     <li>

<a href="#" class="feat-btn">Transacation:-
     <span class="fas fa-caret-down first"></span></a>


        <ul class="feat-show">

           
<li><a href="usercredit.php">Credit</a></li>
           

<li><a href="userdebit.php">Debit</a></li>
        

</ul>


     </li>


     <li>

<a href="#" class="serv-btn">Services:-
     <span class="fas fa-caret-down second"></span></a>



     <ul class="serv-show">
     
   <li><a href="usertransfer.php">Transfer</a></li>

        
<li><a href="contact.php">Help</a></li>
     

</ul>

     

</li>
 <li><a href="userprofile.php">Profile</a></li>

     <li><a href="passpin.php">Change Pin/Paswd</a></li> 
     <li><a href="jsphome.php">Logout</a></li>
  </ul>
</nav>

</body>
</html>